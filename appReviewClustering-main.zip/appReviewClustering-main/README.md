Current project status:
Finished testing the viability of the unsupervised learning approach.
    Conclusion: The task is too complex and poorly-defined to produce meaningful clusters.
Current Task: Pivot to supervised classification task. Calculate centroids for predetermined
classes, and use these to classify new reviews.